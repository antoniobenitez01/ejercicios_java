/*
 * Programa que interactúa con un archivo de Propiedades
 * mediante la clase Property
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 22/09/2025
 */
package configuracion;

import java.util.Properties;
import java.util.Scanner;
import java.io.*;

public class Main 
{
	public static void main(String[] args) 
	{
		System.out.println("\n==== ANÁLISIS ARCHIVOS PROPERTIES ====");
		Scanner entrada = new Scanner(System.in);
		Properties props = new Properties();
		String respuesta;
		do
		{
			System.out.println("\nIntroduzca el nombre del archivo de propiedades a leer."
					+ "\nPara apagar el programa escriba 'fin'.");
			respuesta = entrada.nextLine();
			if(!respuesta.toLowerCase().equals("fin"))
			{
				// BÚSQUEDA ARCHIVO PROPIEDADES =================================
				try 
				{
					props.load(new FileInputStream(respuesta));
					if(props.isEmpty())
					{
						System.out.println("El archivo de Propiedades encontrado está vacío.");
					}else
					{
						//BÚSQUEDA DE PROPIEDAD -------------------------------------------
						System.out.println("Archivo de propiedades encontrado.");
						String respuesta2;
						do
						{
							System.out.println("\nIntroduzca la propiedad que desea buscar:"
									+ "\nPara analizar otro archivo, escriba 'salir'");
							respuesta2 = entrada.nextLine();
							if(!respuesta2.toLowerCase().equals("salir"))
							{
								String str = props.getProperty(respuesta2);
								if(str == null)
								{
									System.out.println("No se ha encontrado la propiedad especificada.");
								}else
								{
									System.out.println(String.format("%s: %s",respuesta2,str));
								}
							}
						}while(!respuesta2.toLowerCase().equals("salir"));
						// ----------------------------------------------------------------
					}
				}catch(FileNotFoundException fnfe)
				{
					System.out.println("No se ha encontrado el archivo.");
				}catch(IOException ioe)
				{
					System.out.println("Ha ocurrido un problema al leer el archivo.");
				}
				// ===================================================================
			}
		}while(!respuesta.toLowerCase().equals("fin"));
		entrada.close();
		System.out.println("Apagando programa ...");
	}
}
