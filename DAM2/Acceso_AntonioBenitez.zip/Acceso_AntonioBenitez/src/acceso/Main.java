package acceso;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Properties;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main 
{
	public static void main(String[] args) 
	{
		Properties props = new Properties();
		int codigo;
		String select;
		try 
		{
			props.load(new FileInputStream("mysql.cnf"));
			String url = String.format("jdbc:mysql://%s:%s/%s",
					props.getProperty("ip"),props.getProperty("port"),props.getProperty("dbname"));
			String user = props.getProperty("user");
			String password = props.getProperty("password");
			Connection conn = connectionSQL(url,user,password);
			if(conn != null)
			{
				Scanner entrada = new Scanner(System.in);
				int respuesta = 0;
				while(respuesta != 6)
				{	
					respuesta = menu(entrada);
					switch(respuesta)
					{
					case 1: // SELECT ----------
						System.out.println("Introduzca el nombre del cliente a buscar.");
						String nombre = entrada.nextLine();
						select = String.format("SELECT * FROM cliente WHERE nombre LIKE ?");
						try
						{
							PreparedStatement stmt = conn.prepareStatement(select);
							stmt.setString(1, "%" + nombre + "%");
							ResultSet rs = stmt.executeQuery();
							int numTablas = 0;
							while(rs.next())
							{
								System.out.println(String.format("Código: %d\nNombre: %s\nDirección: %s"
										+ "\nEmail: %s\nTeléfono: %d\n",
										rs.getInt("codigo"),rs.getString("nombre"),
										rs.getString("direccion"),rs.getString("email"),rs.getInt("telefono")));
								numTablas++;
							}
							if(numTablas == 0)
							{
								System.out.println("No se ha encontrado ninguna fila.");
							}
							rs.close();
							stmt.close();
						}catch(SQLException ex)
						{
							System.out.println("SQL Exception: " + ex.getMessage());
						}
						break;
					case 2: // INSERT ----------
						String insert = "INSERT INTO cliente (nombre, direccion, email, telefono) VALUES (?,?,?,?)";
						try
						{
							PreparedStatement stmt = conn.prepareStatement(insert);
							System.out.println("Introduzca el nombre del cliente a insertar.");
							stmt.setString(1,entrada.nextLine());
							System.out.println("Introduzca la dirección del cliente a insertar.");
							stmt.setString(2,entrada.nextLine());
							System.out.println("Introduzca el email del cliente a insertar.");
							stmt.setString(3, entrada.nextLine());
							stmt.setInt(4,inputPhone("Introduzca el teléfono del cliente a insertar.",entrada));
							int filas = stmt.executeUpdate();
							System.out.println("Filas insertadas : " + filas);
							stmt.close();
						}catch(SQLException ex)
						{
							System.out.println("SQL Exception: " + ex.getMessage());
						}
						break;
					case 3: // UPDATE ----------
						codigo = inputInt("Introduzca el código de cliente.",entrada);
						select = "SELECT * FROM cliente WHERE codigo = ?";
						try
						{
							PreparedStatement stmt = conn.prepareStatement(select);
							stmt.setInt(1, codigo);
							ResultSet rs = stmt.executeQuery();
							int numTablas = 0;
							while(rs.next())
							{
								System.out.println(String.format("Código: %d\nNombre: %s\nDirección: %s"
										+ "\nEmail: %s\nTeléfono: %d\n",
										rs.getInt("codigo"),rs.getString("nombre"),
										rs.getString("direccion"),rs.getString("email"),rs.getInt("telefono")));
								numTablas++;
							}
							if(numTablas > 0) 
							{
								System.out.println("Entrada encontrada, introduzca a continuación los datos a actualizar.");
								String update = "UPDATE cliente SET nombre = ?, direccion = ?, email = ?, telefono = ? WHERE codigo = ?";
								stmt = conn.prepareStatement(update);
								System.out.println("Introduzca el nombre del cliente a actualizar.");
								stmt.setString(1,entrada.nextLine());
								System.out.println("Introduzca la dirección del cliente a actualizar.");
								stmt.setString(2,entrada.nextLine());
								System.out.println("Introduzca el email del cliente a actualizar.");
								stmt.setString(3, entrada.nextLine());
								stmt.setInt(4,inputPhone("Introduzca el teléfono del cliente a actualizar.",entrada));
								stmt.setInt(5, codigo);
								int filas = stmt.executeUpdate();
								System.out.println("Filas actualizadas : " + filas);
							}else
							{
								System.out.println("No se ha encontrado ningún cliente con ese código.");
							}
							rs.close();
							stmt.close();
						}catch(SQLException ex)
						{
							System.out.println("SQL Exception: " + ex.getMessage());
						}
						break;
					case 4: // DELETE ----------
						codigo = inputInt("Introduzca el código de cliente.",entrada);
						select = "SELECT * FROM cliente WHERE codigo = ?";
						try
						{
							PreparedStatement stmt = conn.prepareStatement(select);
							stmt.setInt(1, codigo);
							ResultSet rs = stmt.executeQuery();
							int numTablas = 0;
							while(rs.next())
							{
								System.out.println(String.format("Código: %d\nNombre: %s\nDirección: %s"
										+ "\nEmail: %s\nTeléfono: %d\n",
										rs.getInt("codigo"),rs.getString("nombre"),
										rs.getString("direccion"),rs.getString("email"),rs.getInt("telefono")));
								numTablas++;
							}
							if(numTablas > 0) 
							{
								boolean toDelete = booleanCheck("Entrada encontrada, ¿borrar los datos? (SI / NO).", entrada);
								if(toDelete)
								{
									String update = "DELETE FROM cliente WHERE codigo = ?";
									stmt = conn.prepareStatement(update);
									stmt.setInt(1, codigo);
									int filas = stmt.executeUpdate();
									System.out.println("Filas actualizadas : " + filas);
								}else 
								{
									System.out.println("Operación cancelada, volviendo al menú principal ...");
								}
							}else
							{
								System.out.println("No se ha encontrado ningún cliente con ese código.");
							}
							rs.close();
							stmt.close();
						}catch(SQLException ex)
						{
							System.out.println("SQL Exception: " + ex.getMessage());
						}
						break;
					case 5: // SELECT ALL ------
						try
						{
							select = "SELECT * FROM cliente";
							PreparedStatement stmt = conn.prepareStatement(select);
							ResultSet rs = stmt.executeQuery();
							int numTablas = 0;
							while(rs.next())
							{
								System.out.println(String.format("Código: %d\nNombre: %s\nDirección: %s"
										+ "\nEmail: %s\nTeléfono: %d\n",
										rs.getInt("codigo"),rs.getString("nombre"),
										rs.getString("direccion"),rs.getString("email"),rs.getInt("telefono")));
								numTablas++;
							}
							if(numTablas == 0)
							{
								System.out.println("No se ha encontrado ninguna fila.");
							}
							rs.close();
							stmt.close();
						}catch(SQLException ex)
						{
							System.out.println("SQL Exception: " + ex.getMessage());
						}
						break;
					case 6: // APAGAR ----------
						System.out.println("Apagando programa ...");
						break;
					}
				}
				entrada.close();
			}
			conn.close();
		} catch (IOException e) 
		{
			System.out.println("Input-Output Error: " + e.getMessage());
		} catch (SQLException ex) {
			System.out.println("SQL Error: " + ex.getMessage());;
		}
	}
	
	//MENU - Muestra el menú principal y devuelve el entero de la opción elegida
	public static int menu(Scanner entrada)
	{
		System.out.println("=== FUNCIONES SQL - Tabla Cliente ==="+
						"\n 1. SELECT - Búsqueda por nombre"
				+		"\n 2. INSERT - Insertar nuevo cliente"
				+		"\n 3. UPDATE - Actualizar cliente por código"
				+		"\n 4. DELETE - Borrar cliente por código"
				+		"\n 5. SELECT ALL - Mostrar todos los clientes"
				+		"\n 6. Apagar programa");
		int respuesta = 0;
		while(respuesta < 1 || respuesta > 6)
		{
			respuesta = inputInt("Introduzca la opción a elegir.", entrada);
			if(respuesta < 1 || respuesta > 6)
			{
				System.out.println("Respuesta no válida, inténtelo de nuevo.");
			}
		}
		return respuesta;
	}
	
	//CONNECTION SQL - Intenta conexión SQL con parámetros devolviendo true si se conecta correctamente
	public static Connection connectionSQL(String url, String user, String password)
	{
		System.out.println("Trying SQL Connection ...");
		Connection conn = null;
		try
		{
			conn = DriverManager.getConnection(url,user,password);
			System.out.println("SQL Connection Succesful.");
		}catch(SQLException ex)
		{
			System.out.println("SQL Exception: " + ex.getMessage());
		}
		return conn;
	}
	
	//INPUT INT - Recoge un mensaje String y un objeto Scanner, comprueba si se introduce un valor Integer correctamente
	public static int inputInt(String mensaje, Scanner entrada)
	{
		int num = 0;
		boolean inputTrue = false;
		do
		{
			//EXCEPCIÓN - InputMismatchException - Bucle que asegura que el valor introducido es un valor decimal
			try 
			{
				System.out.println(mensaje);
				num = entrada.nextInt();
				entrada.nextLine(); // Depuración Scanner
				inputTrue = true;
			} catch(InputMismatchException excepcion1)
			{
				System.out.println("Valor introducido incorrecto.");
				entrada.nextLine(); // Depuración Scanner
			}
		}while(inputTrue == false);
		return num;
	}
	
	//INPUT PHONE - Verifica que se introduce correctamente un formato de número de teléfono
	public static int inputPhone(String mensaje, Scanner entrada)
	{
		int phone = 0;
		boolean isPhone = false;
		Pattern phonePat = Pattern.compile("[0-9]{9}");
		while(!isPhone)
		{
			phone = inputInt(mensaje,entrada);
			Matcher matcher = phonePat.matcher(Integer.toString(phone));
			if(matcher.matches())
			{
				isPhone = true;
			}else
			{
				System.out.println("El número de teléfono no sigue el formato estándar (9 números). Inténtelo de nuevo.");
			}
		}
		return phone;
	}
	
	//BOOLEAN CHECK - Devuelve un boolean en base a la respuesta SI o NO introducida por teclado
		private static boolean booleanCheck(String mensaje, Scanner entradaTeclado)
		{
			boolean resultado = false, flag = false;
			do
			{
				System.out.println(mensaje);
				String respuesta = entradaTeclado.nextLine();
				if(respuesta.toLowerCase().equals("si") || respuesta.toLowerCase().equals("sí"))
				{
					resultado = true;
					flag = true;
				}
				else if(respuesta.toLowerCase().equals("no"))
				{
					resultado = false;
					flag = true;
				}
				else
				{
					System.out.println("Respuesta no válida. Inténtelo de nuevo.");
					flag = false;
				}
			}while(flag == false);
			return resultado;
		}
}
