package ejerciciosql;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Properties;
import java.util.Scanner;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main 
{
	public static void main(String[] args) 
	{
		Properties props = new Properties();
		try 
		{
			props.load(new FileInputStream("mysql.cnf"));
			String url = String.format("jdbc:mysql://%s:%s/%s",
					props.getProperty("ip"),props.getProperty("port"),props.getProperty("dbname"));
			String user = props.getProperty("user");
			String password = props.getProperty("password");
			Connection conn = connectionSQL(url,user,password);
			if(conn != null)
			{
				Scanner entrada = new Scanner(System.in);
				int respuesta = 0;
				while(respuesta != 3)
				{	
					respuesta = menu(entrada);
					switch(respuesta)
					{
					case 1: // SELECT ----------
						int codigo = inputInt("Introduzca el código de cliente.",entrada);
						String select = "SELECT * FROM cliente WHERE codigo = ?";
						try
						{
							PreparedStatement stmt = conn.prepareStatement(select);
							stmt.setInt(1, codigo);
							ResultSet rs = stmt.executeQuery();
							while(rs.next())
							{
								System.out.println(String.format("Código: %d\nNombre: %s\nEmail: %s"
										+ "\nSaldo: %.2f€\nFecha de alta: %s\n",
										rs.getInt("codigo"),rs.getString("nombre"),
										rs.getString("email"),rs.getDouble("saldo"),rs.getString("fecha_alta")));
							}
							rs.close();
							stmt.close();
						}catch(SQLException ex)
						{
							System.out.println("SQL Exception: " + ex.getMessage());
						}
						break;
					case 2: // INSERT ----------
						String insert = "INSERT INTO cliente (nombre, email, saldo,fecha_alta) VALUES (?,?,?,?)";
						try
						{
							PreparedStatement stmt = conn.prepareStatement(insert);
							System.out.println("Introduzca el nombre del cliente a insertar");
							stmt.setString(1,entrada.nextLine());
							System.out.println("Introduzca el email del cliente a insertar");
							stmt.setString(2,entrada.nextLine());
							stmt.setDouble(3,inputDouble("Introducza el saldo del cliente a insertar",entrada));
							stmt.setString(4, inputDate("Introduzca la fecha de alta del cliente a insertar", entrada));
							int filas = stmt.executeUpdate();
							System.out.println("Filas insertadas : " + filas);
							stmt.close();
						}catch(SQLException ex)
						{
							System.out.println("SQL Exception: " + ex.getMessage());
						}
						break;
					case 3: // APAGAR ----------
						System.out.println("Apagando programa ...");
						break;
					default:
						break;
					}
				}
				entrada.close();
			}
			conn.close();
		} catch (IOException e) 
		{
			System.out.println("Input-Output Error: " + e.getMessage());
		} catch (SQLException ex) {
			System.out.println("SQL Error: " + ex.getMessage());;
		}
	}
	
	//MENU - Muestra el menú principal y devuelve el entero de la opción elegida
	public static int menu(Scanner entrada)
	{
		System.out.println("=== FUNCIONES SQL ==="+
						"\n 1. SELECT"
				+		"\n 2. INSERT"
				+		"\n 3. Apagar programa");
		int respuesta = 0;
		while(respuesta < 1 || respuesta > 3)
		{
			respuesta = inputInt("Introduzca la opción a elegir.", entrada);
			if(respuesta < 1 || respuesta > 3)
			{
				System.out.println("Respuesta no válida, inténtelo de nuevo.");
			}
		}
		return respuesta;
	}
	
	//CONNECTION SQL - Intenta conexión SQL con parámetros devolviendo true si se conecta correctamente
	public static Connection connectionSQL(String url, String user, String password)
	{
		System.out.println("Trying SQL Connection ...");
		Connection conn = null;
		try
		{
			conn = DriverManager.getConnection(url,user,password);
			System.out.println("SQL Connection Succesful.");
		}catch(SQLException ex)
		{
			System.out.println("SQL Exception: " + ex.getMessage());
		}
		return conn;
	}
	
	//INPUT INT - Recoge un mensaje String y un objeto Scanner, comprueba si se introduce un valor Integer correctamente
	public static int inputInt(String mensaje, Scanner entrada)
	{
		int num = 0;
		boolean inputTrue = false;
		do
		{
			//EXCEPCIÓN - InputMismatchException - Bucle que asegura que el valor introducido es un valor decimal
			try 
			{
				System.out.println(mensaje);
				num = entrada.nextInt();
				entrada.nextLine(); // Depuración Scanner
				inputTrue = true;
			} catch(InputMismatchException excepcion1)
			{
				System.out.println("Valor introducido incorrecto.");
				entrada.nextLine(); // Depuración Scanner
			}
		}while(inputTrue == false);
		return num;
	}
	
	//INPUT DOUBLE - Recoge un mensaje String y un objeto Scanner, comprueba si se introduce un valor Double correctamente
	public static double inputDouble(String mensaje, Scanner entrada)
	{
		double num = 0;
		boolean inputTrue = false;
		do
		{
			//EXCEPCIÓN - InputMismatchException - Bucle que asegura que el valor introducido es un valor decimal
			try 
			{
				System.out.println(mensaje);
				num = entrada.nextDouble();
				entrada.nextLine(); // Depuración Scanner
				inputTrue = true;
			} catch(InputMismatchException excepcion1)
			{
				System.out.println("Valor introducido incorrecto.");
				entrada.nextLine(); // Depuración Scanner
			}
		}while(inputTrue == false);
		return num;
	}
	
	//INPUT DATE - Comprueba si se introduce una fecha SQL formateada correctamente
	public static String inputDate(String mensaje, Scanner entrada)
	{
		Pattern datePattern = Pattern.compile("[0-9]{1,4}-[0-9]{1,2}-[0-9]{1,2}");
		Matcher matcher;
		String respuesta = "";
		boolean flag = false;
		do
		{
			System.out.println(mensaje);
			respuesta = entrada.nextLine();
			matcher = datePattern.matcher(respuesta);
			if(!matcher.matches())
			{
				System.out.println("Formato de fecha incorrecto, inténtelo de nuevo.");
			}else
			{
				LocalDate date = null;
				try
				{
					date = LocalDate.parse(respuesta);
					flag = true;
				}catch(DateTimeParseException ex)
				{
					System.out.println("Fecha no válida, inténtelo de nuevo.");
				}
			}
		}while(!flag);
		return respuesta;
	}
}
