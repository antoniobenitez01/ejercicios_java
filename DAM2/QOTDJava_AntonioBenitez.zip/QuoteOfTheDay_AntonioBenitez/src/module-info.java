/**
 * 
 */
/**
 * 
 */
module QuoteOfTheDay_AntonioBenitez {
}