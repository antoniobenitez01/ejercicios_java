/*
 * Programa que trabajo con la clase Vehículo
 * para guardar los datos de sus objetos en ficheros
 * e interactuar con ellos mediante médotos
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 19/09/2025
 */
package persistencia;

import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		// CREACIÓN ARCHIVO ============================
		
		File vehiculos = new File("coches.txt");
		if(vehiculos.exists()) vehiculos.delete();
		try
		{
			vehiculos.createNewFile();
		}catch(IOException e)
		{
			System.out.println("Ha ocurrido un problema creando el archivo.");
		}
		
		// CREACIÓN OBJETOS VEHÍCULO ===================
		
		Vehiculo veh1 = new Vehiculo("8888AAA","Ford Fiesta",50.50);
		Vehiculo veh2 = new Vehiculo("5555BBB","Seat Ibiza",35.05);
		Vehiculo veh3 = new Vehiculo("3333CCC","Toyota Yaris",60.46);
		
		// UTILIZACIÓN DE MÉTODOS ======================
		
		// Grabación inicial de datos de vehículos ------
		
		System.out.println("--- Grabación vehículos en archivo 'coches.txt'\n");
		System.out.println("Grabando Vehículo 1 ...");
		veh1.grabar(vehiculos);
		System.out.println(veh1.toString() + "\n");
		System.out.println("Grabando Vehículo 2 ...");
		veh2.grabar(vehiculos);
		System.out.println(veh2.toString() + "\n");
		System.out.println("Grabando Vehículo 3 ...");
		veh3.grabar(vehiculos);
		System.out.println(veh3.toString() + "\n");
		
		// Métodos buscar matrícula ----------------------
		
		System.out.println("--- Búsqueda de matrícula ---\n");
		System.out.println("Creando Vehículo por defecto ...");
		Vehiculo defecto = new Vehiculo();
		System.out.println(String.format("Vehículo por defecto: %s",defecto.toString()));
		System.out.println("\nBuscando matrícula 8888AAA ...");
		defecto.buscar("8888AAA", vehiculos);
		System.out.println(String.format("Vehículo por defecto: %s",defecto.toString()));
		
		// Método listar coches ---------------------------
		
		System.out.println("\n--- Listando vehículos en archivo 'coches.txt' ---\n");
		for(Vehiculo v : listar(vehiculos)) System.out.println(v.toString());
	}
	
	//LISTAR - Convierte los elementos de un archivo de texto a un LinkedList
	public static LinkedList<Vehiculo> listar(File file)
	{
		LinkedList<Vehiculo> lista = new LinkedList<Vehiculo>();
		try
		{
			Scanner reader = new Scanner(file);
			while(reader.hasNextLine())
			{
				String[] datos = reader.nextLine().split(";");
				Vehiculo creado = new Vehiculo(datos[0],datos[1],Double.parseDouble(datos[2]));
				if(creado != null) lista.add(creado);
			}
			reader.close();
		}catch(IOException e)
		{
			System.out.println("Ha ocurrido un problema al leer el archivo.");
		}
		return lista;
	}
}
