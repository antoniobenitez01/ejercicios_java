/*
 * Clase que representa la información básica de
 * un objeto Vehículo
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 19/09/2025
 */
package persistencia;

import java.io.*;
import java.util.Locale;
import java.util.Scanner;

public class Vehiculo 
{
	//ATRIBUTOS ======================================
	
	public static final String MATRICULA_DEFAULT = "9999XXX";
	public static final String MODELO_DEFAULT = "Modelo";
	public static final double POTENCIA_DEFAULT = 50;
	
	private String matricula;
	private String modelo;
	private double potencia;
	
	// CONSTRUCTORES =================================
	
	//Constructor completo
	public Vehiculo(String matricula, String modelo, double potencia) throws IllegalArgumentException
	{
		if(matricula.isBlank() || matricula == null)
		{
			throw new IllegalArgumentException("El campo de matrícula no puede estar vacío o ser nulo.");
		}
		if(modelo.isBlank() || modelo == null)
		{
			throw new IllegalArgumentException("El campo de modelo no puede estar vacío o ser nulo.");
		}
		if(potencia < 0)
		{
			throw new IllegalArgumentException("La potencia no puede ser menor que 0.");
		}
		this.matricula = matricula;
		this.modelo = modelo;
		this.potencia = potencia;
	}
	
	//Constructor por omisión
	public Vehiculo()
	{
		this(MATRICULA_DEFAULT, MODELO_DEFAULT, POTENCIA_DEFAULT);
	}
	
	// GETTERS SETTERS ================================
	
	public String getMatricula()
	{
		return this.matricula;
	}
	
	public String getModelo()
	{
		return this.modelo;
	}
	
	public double getPotencia()
	{
		return this.potencia;
	}
	
	// MÉTODOS ========================================
	
	//GRABAR - Graba el contenido del objeto Vehículo en el archivo pasado por parámetro
	public void grabar(File file)
	{
		try
		{
			FileWriter writer = new FileWriter(file, true);
			writer.write(String.format("%s%n",this.toExport()));
			System.out.println(String.format("Vehículo con matrícula %s grabado correctamente en archivo %s.",
					this.matricula, file.getName()));
			writer.close();
		}catch(IOException e)
		{
			System.out.println("Se ha producido un error al grabar el vehículo.");
		}
	}
	
	//BUSCAR - Busca la matrícula introducida por parámetro en el archivo de texto introduciod
	public void buscar(String matricula, File file)
	{
		try
		{
			Scanner reader = new Scanner(file);
			boolean confirmado = false;
			while(reader.hasNextLine())
			{
				String[] datos = reader.nextLine().split(";");
				if(datos[0].equals(matricula))
				{
					this.matricula = datos[0];
					this.modelo = datos[1];
					this.potencia = Double.parseDouble(datos[2]);
					confirmado = true;
				}
			}
			if(confirmado)
			{
				System.out.println("Se ha encontrado la matrícula introducida y se han copiado los datos al objeto.");
			}else
			{
				System.out.println("No se ha encontrado la matrícula introducida.");
			}
			reader.close();
		}catch(IOException e)
		{
			System.out.println("Ha ocurrido un problema al leer el archivo.");
		}
	}
	
	//TO STRING - Transforma el objeto Vehículo en un objeto String con todos sus atributos
	public String toExport()
	{
		return String.format(Locale.US, "%s;%s;%.2f",this.matricula,this.modelo,this.potencia);
	}
	
	//TO STRING - Transforma el objeto Vehículo en un objeto String con todos sus atributos
	public String toString()
	{
		return String.format("Matrícula: %s - Modelo: %s - Potencia %.2f",this.matricula,this.modelo,this.potencia);
	}
}
