/*
 * Objetivo: Programa que crea variables
 * y las imprime de forma organizada.
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 01/10/2024
 */
package ejercicio3;

public class Ejercicio3 
{

	public static void main(String[] args) 
	{
		//Declaración variables
		int num1 = 1, num2 = 1;
		char char1, char2;
		String cargo = "Programador", nombre = "Antonio";
		
		//Asignación valores char
		char1 = 'a';
		char2 = 'b';
		
		//Muestra las variables int
		System.out.println("El valor de num1 es: " + num1
						  + "\ny el valor de num2 es: " + num2);
		System.out.println("Bienvenido, " + cargo + " " + nombre + ".");
		
	}

}
