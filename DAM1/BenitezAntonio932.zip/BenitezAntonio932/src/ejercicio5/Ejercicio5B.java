package ejercicio5;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
/*
 * Clase principal que hace uso de las clases
 * File, FileWriter y Scanner para 
 * crear un programa que crea archivos de todas
 * las letras del abecedario con todas las palabras
 * que empiecen por esa letra
 * Exceptions: IOException, FileNotFoundException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 08/04/2025
 */
public class Ejercicio5B 
{
	public static void main(String[] args) 
	{
		System.out.println("\n -- DICCIONARIO --\n");
		File diccionario = new File("Documentos/Diccionario");
		if(!diccionario.exists())
		{
			System.out.println("Creando carpeta de Diccionario ...\n");
			diccionario.mkdir();
		}
		System.out.println("-- Creando archivos de Letras --\n");
		for(int i=65; i<91;i++)
		{
			char caracter = (char) i;
			System.out.printf("Creando archivo de texto de la letra %c\n", caracter);
			File nuevoArchivo = new File(String.format("Documentos/Diccionario/%c.txt", caracter));
			crearArchivoLetra(nuevoArchivo, caracter);
		}
		//TRATAMOS EL CASO ESPECIAL "Ñ"
		System.out.printf("Creando archivo de texto de la letra Ñ\n");
		File n = new File("Documentos/Diccionario/Ñ.txt");
		crearArchivoLetra(n, 'Ñ');
		
		System.out.println("\nDiccionario creado con exito.");
	}
	
	//CREAR ARCHIVO LETRA - Escribe un contenido importado el archivo introducido por parámetro
	private static void crearArchivoLetra(File archivo, char letra)
	{
		FileWriter writer = null;
		try 
		{
			writer = new FileWriter(archivo, true);
			String contenido = importarContenido(letra);
			writer.write(contenido);
		} catch (IOException e) 
		{
			System.out.printf("%s\n", e.getMessage());
		}
		try 
		{
			writer.close();
		} catch (IOException e) 
		{
			System.out.printf("%s\n", e.getMessage());
		}
	}
	
	//IMPORTAR CONTENIDO - Devuelve un String con todas las palabras que empiecen por el carácter pasado por parámetro
	private static String importarContenido(char letra)
	{
		File archivo = new File("Documentos/diccionario.txt");
		Scanner reader = null;
		String resultado = "";
		try 
		{
			reader = new Scanner(archivo);
		} catch (FileNotFoundException e) 
		{
			System.out.printf("%s\n", e.getMessage());
		}
		if(reader != null)
		{
			while(reader.hasNextLine())
			{
				String palabra = reader.nextLine();
				String primeraLetra = String.valueOf(palabra.charAt(0));
				if(primeraLetra.toLowerCase().equals(String.valueOf(letra).toLowerCase()))
				{
					resultado += String.format("%s\n", palabra);
				}
			}
		}
		return resultado;
	}
}
