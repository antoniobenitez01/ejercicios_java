/*
 * Objetivo: Programa que muestra los 
 * 20 primeros números naturales.
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 16/10/2024
 */
package ejercicio1;

public class Ejercicio1 
{

	public static void main(String[] args) 
	{
		int num=1;
		
		for(int i=1; i<=20; i++)
		{
			System.out.println(num);
			num++;
		}
	}

}
