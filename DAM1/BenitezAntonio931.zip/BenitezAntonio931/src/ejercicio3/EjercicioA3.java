package ejercicio3;

import java.io.File;
/*
 * Clase principal que hace uso de la clase File
 * para renombrar archivos y carpetas
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 04/04/2025
 */
public class EjercicioA3 
{
	public static void main(String[] args) 
	{
		// REINICIO DE NOMBRES
		File documentos = new File("DOCS");
		documentos.renameTo(new File("Documentos"));
		
		File fotografias = new File("Documentos/FOTOS");
		fotografias.renameTo(new File("Documentos/Fotografias"));
		
		File libros = new File("Documentos/LECTURAS");
		libros.renameTo(new File("Documentos/Libros"));
		// *******************
		
		/*Cambiar el nombre de la carpeta ‘Documentos’ a ‘DOCS’, el de la carpeta ‘Fotografias’ a
		‘FOTOS’ y el de la carpeta ‘Libros’ a ‘LECTURAS’*/
		documentos = new File("Documentos");
		documentos.renameTo(new File("DOCS"));
		
		fotografias = new File("DOCS/Fotografias");
		fotografias.renameTo(new File("DOCS/FOTOS"));
		
		libros = new File("DOCS/Libros");
		libros.renameTo(new File("DOCS/LECTURAS"));
		/*Cambiar el nombre de todos los archivos de las carpetas FOTOS y LECTURAS quitándole la
		extensión. Por ejemplo, ‘astronauta.jpg’ pasará a llamarse ‘astronauta’.*/
		
		File fotos = new File("DOCS/FOTOS");
		File[] archFotos = fotos.listFiles();
		removerExtension(archFotos, "DOCS/FOTOS/%s");
		
		File lecturas = new File("DOCS/LECTURAS");
		File[] archLecturas = lecturas.listFiles();
		removerExtension(archLecturas, "DOCS/LECTURAS/%s");
	}
	
	//REMOVER EXTENSIÓN - Método que recoge un array de objetos File y los renombra al mismo archivo pero sin extensión
	private static void removerExtension(File[] archivos, String ruta)
	{
		for(int i=0; i<archivos.length;i++)
		{
			File nuevoArchivo = new File(String.format(ruta, 
					archivos[i].getName().substring(0, archivos[i].getName().length() - 4)));
			archivos[i].renameTo(nuevoArchivo);
		}
	}
}
