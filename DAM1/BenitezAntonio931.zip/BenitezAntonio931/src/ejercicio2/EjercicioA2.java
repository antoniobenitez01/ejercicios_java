package ejercicio2;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Scanner;
import java.util.TimeZone;
/*
 * Clase principal que hace uso de la clase File
 * para mostrar la información de archivos y directorios
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 04/04/2025
 */
public class EjercicioA2
{
	public static void main(String[] args)
	{
		Scanner entradaTeclado = new Scanner(System.in);
		String entrada = "";
		do
		{
			System.out.println("Introduzca la ruta por teclado o presione Enter para apagar el programa.");
			entrada = entradaTeclado.nextLine();
			File ruta = new File(entrada);
			boolean info = booleanCheck("¿Quiere mostrar la información detallada de los archivos?", entradaTeclado);
			try 
			{
				muestraInfoRuta(ruta, info);
			} catch (FileNotFoundException e) 
			{
				System.out.printf("%s\n", e.getMessage());
			}			
		}while(!entrada.isEmpty());
		System.out.println("Apagando programa ...");
	} 
	
	//MUESTRA INFO RUTA - Muestra por consola el nombre y los archivos y directorios de la ruta introducida
	public static void muestraInfoRuta(File ruta, boolean info) throws FileNotFoundException
	{
		if(ruta.isFile())
		{
			mostrarArchivo(ruta,"Nombre del archivo: %s", info);
		}else if(ruta.isDirectory())
		{
			mostrarArchivo(ruta,"Nombre del directorio: %s", info);
			File[] archivos = ruta.listFiles();
			Arrays.sort(archivos);
			for(int i=0;i<archivos.length;i++)
			{
				if(archivos[i].isDirectory())
				{
					mostrarArchivo(archivos[i],"%s[*]", info);
				}
			}
			for(int i=0;i<archivos.length;i++)
			{
				if(archivos[i].isFile())
				{
					mostrarArchivo(archivos[i],"%s[A]", info);
				}
			}
		}else
		{
			throw new FileNotFoundException("La ruta introducida no es válida.");
		}
	}
	
	//MOSTRAR ARCHIVO - Recoge un archivo y muestra su información
	private static void mostrarArchivo(File f, String mensaje, boolean info)
	{
		System.out.printf(mensaje, f.getName());
		if(info)
		{
			LocalDateTime lastMod = LocalDateTime.ofInstant(Instant.ofEpochMilli(f.lastModified()), 
                    TimeZone.getDefault().toZoneId());
			System.out.printf("- Tamaño: %d bytes - Última modificación: %s\n", 
					f.length(), dateTimeFormat(lastMod));
		}else
		{
			System.out.print("\n");
		}
	}
	
	//BOOLEAN CHECK - Devuelve un boolean en base a la respuesta SI o NO introducida por teclado
	private static boolean booleanCheck(String mensaje, Scanner entradaTeclado)
	{
		boolean resultado = false, flag = false;
		
		do
		{
			System.out.println(mensaje);
			String respuesta = entradaTeclado.nextLine();
			
			if(respuesta.toLowerCase().equals("si") || respuesta.toLowerCase().equals("sí"))
			{
				resultado = true;
				flag = true;
			}
			else if(respuesta.toLowerCase().equals("no"))
			{
				resultado = false;
				flag = true;
			}
			else
			{
				System.out.println("Respuesta no válida. Inténtelo de nuevo.");
				flag = false;
			}
		}while(flag == false);
		
		return resultado;
	}
	
	//DATE FORMAT - Introduce un objeto LocalDate por parámetro y lo devuelve formateado como un String
	protected static String dateTimeFormat(LocalDateTime dateTime)
	{
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
		return dateTime.format(formato);
	}
}
