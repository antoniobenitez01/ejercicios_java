package ejercicio4;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
/*
 * Clase principal que hace uso de las clases
 * File, Files, Path y Paths
 * para mover un archivo de un path de origen a un path de destino
 * Exceptions: Exception
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 07/04/2025
 */
public class EjercicioA4 
{
	public static void main(String[] args) 
	{
		/*Implementa un programa que cree, dentro de ‘Documentos’, 
		dos nuevas carpetas: ‘Mis Cosas’ y ‘Alfabeto’.*/	
		
		File carpeta = new File("Documentos/Mis Cosas");
		if(!carpeta.exists())
		{
			carpeta.mkdir();
		}
		carpeta = new File("Documentos/Alfabeto");
		if(!carpeta.exists())
		{
			carpeta.mkdir();
		}
		
		/*Mueve las carpetas ‘Fotografias’ y ‘Libros’ dentro de ‘Mis Cosas’.*/
		
		moverArchivo("Documentos/Fotografias", "Documentos/Mis Cosas/Fotografias");
		moverArchivo("Documentos/Libros","Documentos/Mis Cosas/Libros");
		
		/*Luego crea dentro de ‘Alfabeto’ una carpeta por cada letra 
		 * del alfabeto (en mayúsculas): ‘A’, ‘B’, ‘C’... ‘Z’.*/
		
		for(int i=65; i<91;i++)
		{
			char caracter = (char) i;
			File nuevaCarpeta = new File(String.format("Documentos/Alfabeto/%c", caracter));
			if(!nuevaCarpeta.exists())
			{
				nuevaCarpeta.mkdir();
			}
		}
	}
	
	//MOVER CARPETA - Mueve un archivo de un path de origen a un path de destino
	private static void moverArchivo(String origen, String destino)
	{
		Path pOrigen = Paths.get(origen);
		Path pDestino = Paths.get(destino);
		try 
		{
		    Files.move(pOrigen, pDestino);
		} catch (Exception e) 
		{
		    System.out.printf("%s\n",e.getMessage());
		}
	}
}
