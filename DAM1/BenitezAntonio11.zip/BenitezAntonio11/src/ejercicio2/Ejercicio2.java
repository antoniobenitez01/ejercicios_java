/** El objetivo de este ejercicio es mostrar en pantalla
 * una serie de frases y palabras de forma ordenada.
 */
package ejercicio2;

public class Ejercicio2 
{

	public static void main(String[] args) 
	{
		/*Código que imprime por pantalla una frase, utilizando la librería de System.
		 * En este caso, he utilizado múltiples líneas con un solo println, siguiendo
		 * las convenciones de código de Java; es decir, utilizando "+" para añadir
		 * una línea nueva al println y el prefijo "\n" para que Java detecte que 
		 * se trata de una nueva línea a la hora de imprimirlo.
		 */
		
		System.out.println("Desarrollo de Aplicaciones WEB/Multiplataforma"
				+ "\n1DAW / DAM"
				+ "\nMódulos:"
				+ "\nPRO"
				+ "\nSIS");

	}

}
