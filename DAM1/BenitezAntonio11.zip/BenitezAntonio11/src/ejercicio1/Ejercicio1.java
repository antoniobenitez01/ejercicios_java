/**El objetivo de este ejercicio es mostrar en pantalla
 * el mensaje "Este es mi primer programa Java."
 */
package ejercicio1;

public class Ejercicio1 
{
	
	public static void main(String[] args) 
	{
		//Código que imprime por pantalla una frase, utilizando la librería de System
		System.out.println("Este es mi primer programa Java.");
	}
	
}
