/*
 * Objetivo: Programa que muestra una pirámida
 * hecha por astericos cuya base son 9 astericos.
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 07/10/2024
 */
package ejercicio5;

public class Ejercicio5 
{

	public static void main(String[] args) 
	{
		System.out.println("    *    ");
		System.out.println("   ***   ");
		System.out.println("  *****  ");
		System.out.println(" ******* ");
		System.out.println("*********");
	}

}
