/*
 * Objetivo: Programa que crea una pirámide
 * hueca hecha por astericos similar a Ejercicio6
 * pero invertida con el vértice hacia abajo.
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 07/10/2024
 */
package ejercicio7;

public class Ejercicio7 
{

	public static void main(String[] args) 
	{
		System.out.println("*********");
		System.out.println(" *     * ");
		System.out.println("  *   *  ");
		System.out.println("   * *   ");
		System.out.println("    *    ");
	}

}
