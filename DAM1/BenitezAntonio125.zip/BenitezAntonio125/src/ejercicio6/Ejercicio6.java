/*
 * Objetivo: Programa que muestra una
 * pirámide hueca hecha con astericos,
 * similar a Ejercicio5.
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 07/10/2024
 */
package ejercicio6;

public class Ejercicio6 
{

	public static void main(String[] args) 
	{
		System.out.println("    *    ");
		System.out.println("   * *   ");
		System.out.println("  *   *  ");
		System.out.println(" *     * ");
		System.out.println("*********");
	}

}
