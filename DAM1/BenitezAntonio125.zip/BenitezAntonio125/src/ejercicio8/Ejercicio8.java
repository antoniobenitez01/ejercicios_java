/*
 * Objetivo: Programa que pinte un dibujo
 * a partir de símbolo Unicode.
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 07/10/2024
 */
package ejercicio8;

public class Ejercicio8 
{

	public static void main(String[] args) 
	{
		System.out.println("       ===========         ");
		System.out.println("      // //  |    ||_____  ");
		System.out.println("     ||  ---------     | | ");
		System.out.println("     == //\\ ===== //\\====");
		System.out.println(". .     \\//       \\//    ");
		

	}

}
