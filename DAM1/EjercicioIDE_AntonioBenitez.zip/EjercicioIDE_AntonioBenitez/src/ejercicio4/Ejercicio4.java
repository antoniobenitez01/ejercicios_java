package ejercicio4;

public class Ejercicio4 
{

	public static void main(String[] args) 
	{
		System.out.println("Incremento de uno en uno.");
		for(int i = 1; i<51; i++)
		{
			System.out.println(i);
		}
		System.out.println("Incrementos de dos en dos.");
		for(int i = 2; i<51; i++)
		{
			System.out.println(i);
			i++;
		}
	}
}
