/*
 * Objetivo: Programa que usa
 * el bucle while para mostrarnos
 * todos los números desde
 * el 1 al 100.
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 14/10/2024
 */
package ejercicio1;

public class Ejercicio1 
{

	public static void main(String[] args) 
	{
		//Declaración variable
		int num1 = 1;
		
		//Bucle while
		while(num1 <= 100)
		{
			System.out.println(num1);
			num1++;
		}
	}

}
