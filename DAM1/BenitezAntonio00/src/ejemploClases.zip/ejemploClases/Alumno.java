package ejemploClases;

import java.time.LocalDate;
import java.time.LocalTime;

public class Alumno 
{
	public final static int NUMERO_MAXIMO_ALUMNOS = 1000;
	public final static LocalTime HORA_MAXIMA_GENERAL = LocalTime.of(22, 00);
	public final static int NUMERO_MAX_GRUPO = 35;
	private static int numeroMinGrupo = 5;
	private static int numeroAlumnos;
	
	private LocalTime horaMaximaAlumno = LocalTime.of(15,30);
	private String dni;
	private String nombre;
	private String apellidos;
	private LocalDate fechaNacimiento;
	private double peso;
	private double altura;
	private int numeroHermanos;
	private boolean mayorEdad;
	
	public Alumno(String dni, String nombre, String apellidos, LocalDate fechaNacimiento, double peso, double altura, int numeroHermanos, boolean mayorEdad, LocalTime horaMaximaAlumno)
	{
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNacimiento = fechaNacimiento;
		this.peso = peso;
		this.altura = altura;
		this.numeroHermanos = numeroHermanos;
		this.mayorEdad = mayorEdad;
		this.horaMaximaAlumno = horaMaximaAlumno;
		
		Alumno.numeroAlumnos++;
	}
}
