package ejemploClases;

import java.time.LocalDate;
import java.time.LocalTime;

public class Main {

	public static void main(String[] args) 
	{
		Alumno alumno1;
		alumno1 = new Alumno("26267841R", "Antonio", "Benítez Rodríguez", LocalDate.of(2001, 12, 28), 81.45, 1.87, 1, true, LocalTime.of(21, 30));
	}

}
