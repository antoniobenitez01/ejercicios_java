/*
 * Clase que representa una Bombilla
 * Excepciones: IllegalArgumentException, IllegalStateException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 20/01/2025
 */
package claseBombilla;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class Bombilla 
{
	//ATRIBUTOS ====================================================
	
	public static final double POTENCIA_MAX = 1000.00; //FINAL - Potencia máxima
	public static final double POTENCIA_MIN = 10.00; //FINAL - Potencia mínima
	public static final double POTENCIA_DEFAULT = 100.00; //FINAL - Potencia por defecto
	private static int bombillasCreadas; // Número de bombillas creadas en total
	private static int bombillasEncedidas; // Número de bombillas encendidas en el momento
	
	private boolean encendida; // Booleano que es true cuando la bombilla está encendida
	private int numeroVecesEncendida; // Número de veces que la bombilla ha sido encendida
	private double potencia; // Potencia de la bombilla
	private double tiempoEncendida; // Tiempo que lleva encendida la bombilla
	private LocalTime ultimaVezEncendida; // Objeto LocalTime de la última vez en la que se encendió la bombilla
	
	//CONSTRUCTORES =================================================
	
	//	Constructor maestro de dos parámetros (encendida y potencia)
	public Bombilla(boolean encendida, double potencia)
	{
		//----- excepciones
		if(potencia > POTENCIA_MAX) //EXCEPCIÓN - IllegalArgumentException - La potencia no puede ser mayor que el máximo
		{
			throw new IllegalArgumentException ("Potencia mayor que la potencia máxima permitida (" + POTENCIA_MAX + "W).");
		}
		if(potencia < POTENCIA_MIN) //EXCEPCIÓN - IllegalArgumentException - La potencia no puede ser menor que el mínimo
		{
			throw new IllegalArgumentException ("Potencia menor que la potencia mínima permitida (" + POTENCIA_MIN + "W).");
		}
		
		//----- construcción objeto
		this.encendida = encendida;
		if(encendida)
		{
			this.numeroVecesEncendida = 1;
			Bombilla.bombillasEncedidas++;
			this.ultimaVezEncendida = LocalTime.now();
		}
		else
		{
			this.numeroVecesEncendida = 0;
		}
		this.potencia = potencia;
		this.tiempoEncendida = 0;
		
		//----- variables static
		Bombilla.bombillasCreadas++;
	}
	
	//	Constructor de un parámetro (encendida)
	public Bombilla(boolean encendida)
	{
		this(encendida, POTENCIA_DEFAULT);
	}
	
	//	Constructor por omisión
	public Bombilla()
	{
		this(false, POTENCIA_DEFAULT);
	}
	
	// GETTERS Y SETTERS ================================================
	
	//	Devuelve el número entero de bombillas creadas en total
	public static int getBombillasCreadas()
	{
		return Bombilla.bombillasCreadas;
	}
	
	//	Devuelve el número entero de bombillas encendidas en el momento
	public static int getBombillasEncendidas()
	{
		return Bombilla.bombillasEncedidas;
	}
	
	//	Devuelve un valor booleano que representa el estado de la bombilla
	public boolean getEncendida()
	{
		return this.encendida;
	}
	
	//	Devuelve el número entero de veces que se ha encendido la bombilla
	public int getNumeroVecesEncendida()
	{
		return this.numeroVecesEncendida;
	}
	
	//	Devuelve el valor decimal double de potencia de la bombilla
	public double getPotencia()
	{
		return this.potencia;
	}
	
	//	Establece la potencia de la bombilla mediante un parámetro decimal double
	public void setPotencia(double potencia) throws IllegalArgumentException
	{
		if(potencia > POTENCIA_MAX) //EXCEPCIÓN - IllegalArgumentException - La potencia no puede ser mayor que el máximo
		{
			throw new IllegalArgumentException ("Potencia mayor que la potencia máxima permitida (" + POTENCIA_MAX + "W).");
		}
		if(potencia < POTENCIA_MIN) //EXCEPCIÓN - IllegalArgumentException - La potencia no puede ser menor que el mínimo
		{
			throw new IllegalArgumentException ("Potencia menor que la potencia mínima permitida (" + POTENCIA_MIN + "W).");
		}
		this.potencia = potencia; 
	}
	
	//	Devuelve el tiempo (en horas) que lleva encendida la bombilla
	public double getTiempoEncendida()
	{
		return this.tiempoEncendida;
	}
	
	// MÉTODOS =============================================================
	
	//	Calcula el consumo de la bombilla
	public double calcularConsumo()
	{
		return this.potencia * this.tiempoEncendida;
	}
	
	//	Enciende la bombilla (encendida = true)
	public void encender() throws IllegalStateException
	{
		if(this.encendida == true) // EXCEPCIÓN - IllegalStateException - No se puede encender la bombilla si ya está encendida.
		{
			throw new IllegalStateException ("La bombilla ya está encendida.");
		}
		else
		{
			this.encendida = true;
			this.ultimaVezEncendida = LocalTime.now();
			this.numeroVecesEncendida++;
			Bombilla.bombillasEncedidas++;
		}
	}
	
	//	Apaga la bombilla (encendida = false)
	public void apagar() throws IllegalStateException
	{
		if(this.encendida == false) // EXCEPCIÓN - IllegalStateException - No se puede apagar la bombilla si ya está apagada.
		{
			throw new IllegalStateException ("La bombilla ya está apagada.");
		}
		else
		{
			this.encendida = false;
			Bombilla.bombillasEncedidas--;
			//No lo convertimos a ChronoUnit.HOURS directamente para más precisión del tiempo.
			this.tiempoEncendida += (this.ultimaVezEncendida.until(LocalTime.now(), ChronoUnit.SECONDS)) / 3600;
			this.ultimaVezEncendida = null;  //No apunta a nada porque está apagada
		}
	}
	
	//	Conmuta la bombilla dependiendo de su estado
	public void conmutar()
	{
		if(this.encendida == true)
		{
			this.encendida = false;
			Bombilla.bombillasEncedidas--;
			this.tiempoEncendida += (this.ultimaVezEncendida.until(LocalTime.now(), ChronoUnit.SECONDS)) / 3600;
			this.ultimaVezEncendida = null;
		}
		else
		{
			this.encendida = true;
			this.ultimaVezEncendida = LocalTime.now();
			this.numeroVecesEncendida++;
			Bombilla.bombillasEncedidas++;
		}
	}
	
	//	Método toString que devuelve un objeto String que representa la información detallada de la Bombilla
	public String toString()
	{
		return String.format("Bombilla %s. Se ha encendido %d %s.", 
				this.encendida ? "encendida" : "apagada", 
				this.numeroVecesEncendida, 
				this.numeroVecesEncendida == 1 ? "vez" : "veces");
	}
}
