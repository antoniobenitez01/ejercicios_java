package ejemploHerencia;

public class Main {

	public static void main(String[] args) 
	{
		
		Programador programador1 = new Programador();
		System.out.println("\n" + programador1.toString());
		
		Analista analista1 = new Analista();
		System.out.println("\n" + analista1.toString());
		
		Ingeniero ingeniero1 = new Ingeniero();
		System.out.println("\n" + ingeniero1.toString());
		
		System.out.printf("\nNúmero de trabajadores en total: %d \n", Trabajador.getNumeroTrabajadores());
		
		//======================================
		
		System.out.printf("\nProgramador 1 - Nómina: %.2f" +
						"\nAnalista 1 - Nómina: %.2f" +
						"\nIngeniero 1 - Nómina: %.2f",
						programador1.calcularNomina(Trabajador.SALARIO_BASE_DEFAULT),
						analista1.calcularNomina(Trabajador.SALARIO_BASE_DEFAULT), ingeniero1.calcularNomina(Trabajador.SALARIO_BASE_DEFAULT));
		
		System.out.printf("\n\nProgramador 1 - Días vacaciones: %d" +
				"\nAnalista 1 - Días vacaciones: %d" +
				"\nIngeniero 1 - Días vacaciones: %d",
				programador1.calcularVacaciones(), analista1.calcularVacaciones(), ingeniero1.calcularVacaciones());
	}
}
