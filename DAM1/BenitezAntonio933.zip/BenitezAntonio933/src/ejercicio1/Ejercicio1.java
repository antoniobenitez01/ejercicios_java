package ejercicio1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Ejercicio 1: Lectura/escritura de un recetario en ficheros de texto.
 *
 * @author Antonio Benítez Rodríguez
 */
public class Ejercicio1 
{
    /**
     * Método principal.
     *
     * @param args argumentos que recibe el método
     */
    public static void main(String args[]) 
    {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        // Variables de salida
        // Variables auxiliares
    	
        String rutaRecetas = System.getProperty("user.dir") + "/recursos/ListadoRecetas.txt"; 

        //----------------------------------------------
        //       Entrada de datos + Procesamiento
        //----------------------------------------------
        
        //1. Se crea un objeto de tipo Recetario para albergar cada una de las recetas.
        System.out.println("\n1. Creando objeto Recetario ...\n");
        Recetario recetario = new Recetario();
        System.out.printf("%s\n", recetario.toString());
        
        /*2. Leer el archivo de texto ListadoRecetas.txt, que contiene una receta por línea. Cada
			 dato dentro de la receta se separa por el carácter ";".*/
        System.out.println("\n2. Leyendo archivo ListadoRecetas.txt ...\n");
        File listaRecetas = new File(rutaRecetas);
        Scanner reader = null;
        try
        {
        	reader = new Scanner(listaRecetas);
        	while(reader.hasNextLine())
        	{
        		System.out.printf("%s\n", reader.nextLine());
        	}
        }catch(FileNotFoundException e)
        {
        	System.out.printf("%s\n",e.getMessage());
        }
        
        /*3. Se extraen los datos de cada una de las recetas: nombre, tipo de plato, fecha de
        	 creación, listado de ingredientes e instrucciones.*/
        System.out.println("\n3-6. Extrayendo los datos de cada una de las recetas ...\n");
        int contador = 1;
        ArrayList<Receta> recetas = new ArrayList<Receta>();
        try
        {
        	reader = new Scanner(listaRecetas);
            while(reader.hasNextLine())
            {
            	//6. Una vez creado el objeto, se añade al objeto Recetario.
            	System.out.printf("Importando receta Nº%d\n", contador);
            	recetas.add(importarReceta(reader.nextLine()));
            	contador++;
            }
        }catch(FileNotFoundException e)
        {
        	System.out.printf("%s\n",e.getMessage());
        }
        
        /*7. Cuando todas las recetas hayan sido incluidas en el Recetario, se genera su
			 representación textual mediante el método toString() y se escribe cada receta en el
			 archivo de texto Recetario.txt, siguiendo el formato que se indica en el ejemplo de
			 ejecución.*/
        System.out.println("\n7. Mostrando contenido de objeto Recetario ...\n");
        recetario.setRecetas(recetas);
        System.out.printf("%s\n", recetario.toString());
        
        System.out.println("Creando archivo Recetario.txt ...");
        
        File archivoRecetario = new File("Recetario.txt");
        if(archivoRecetario.exists())
        {
        	archivoRecetario.delete();
        }
        try
        {
        	FileWriter writer = new FileWriter(archivoRecetario);
        	String mensajeStart = "***********************************************************************"
        			+ "\nLIBRO DE RECETAS"
        			+ "\n***********************************************************************\n";
        	writer.write(mensajeStart);
        	writer.close();
        }catch(IOException e)
        {
        	System.out.printf("%s\n",e.getMessage());
        }
        
        System.out.println("\nImportando recetas en Recetario.txt ...");
        
        for(Receta i: recetas)
        {
        	exportarReceta(i, "Recetario.txt");
        }
    }
    
    //IMPORTAR RECETAS - Construye un objeto de la clase Receta a partir de un String
    private static Receta importarReceta(String linea)
    {
    	/*4. Se extraen los ingredientes de manera individual y se insertan en una lista. Cada
			 ingrediente se separa por el carácter ",".*/
    	String[] datos = linea.split(";");
    	
    	LocalDate fechaCreada = LocalDate.parse(datos[2]);
    	ArrayList<String> ingredientes = importarIngredientes(datos[3]);
    	/*5. Para cada receta generamos un objeto de tipo Receta con los datos extraídos en los
			 puntos anteriores*/
    	Receta recetaCreada = null;
    	try
    	{
    		recetaCreada = new Receta(datos[0], datos[1], fechaCreada, ingredientes, datos[4]);
    	}catch(NullPointerException e)
    	{
    		System.out.printf("%s\n", e.getMessage());
    	}
    	return recetaCreada;
    }
    
    //IMPORTAR INGREDIENTES - Crea una lista de ingredientes a través de un String
    private static ArrayList<String> importarIngredientes(String linea)
    {
    	String[] datos = linea.split(",");
    	ArrayList<String> ingredientes = new ArrayList<String>();
    	for(int i=0; i<datos.length; i++)
    	{
    		ingredientes.add(datos[i]);
    	}
    	return ingredientes;
    }
    
    //EXPORTAR RECETA - Exporta un objeto Receta a la ruta pasada por parámetro
    private static void exportarReceta(Receta receta, String ruta)
    {
    	FileWriter writer;
    	try
    	{
    		writer = new FileWriter(ruta, true);
    		String recetaString = String.format("NOMBRE DE LA RECETA: %s"
    				+ "\nTIPO DE PLATO: %s"
    				+ "\nFECHA DE CREACIÓN: %s"
    				+ "\nINGREDIENTES: %s"
    				+ "\nINSTRUCCIONES:"
    				+ "\n%s"
    				+ "\n***********************************************************************\n",
    				receta.getNombre(), receta.getTipoPlato(), dateFormat(receta.getFechaCreacion()),
    				receta.getIngredientes().toString(), ordenarInstrucciones(receta.getInstrucciones()));
    		writer.write(recetaString);
    		writer.close();
    	}catch(IOException e)
    	{
    		System.out.printf("%s\n", e.getMessage());
    	}
    }
    
    //ORDENAR INSTRUCCIONES - Recoge un String de instrucciones y devuelve un String ordenado
    private static String ordenarInstrucciones(String instrucciones)
    {
    	String[] datos = instrucciones.split(".");
    	String string = "";
    	for(int i=0; i<datos.length;i++)
    	{
    		System.out.println(datos[i]);
    		string += String.format("%d.- %s\n",i,datos[i]);
    	}
    	return string;
    }
    
	//DATE FORMAT - Introduce un objeto LocalDate por parámetro y lo devuelve formateado como un String
	protected static String dateFormat(LocalDate date)
	{
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return date.format(formato);
	}
}
