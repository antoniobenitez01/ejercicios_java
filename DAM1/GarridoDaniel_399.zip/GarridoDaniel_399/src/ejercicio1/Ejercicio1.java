package ejercicio1;

// DANIEL GARRIDO ESPARTAL 			PRACTICA 399 
import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner (System.in);
		
		
		// Creamos el array bidimensional para 5 filas y 4 columnas
		int [][] tablero = new int [5][4];
		
	
		
		System.out.println(" dime un numero del 1 al 10 ");
		int numero = teclado.nextInt();
		for ( int i = 0; i < tablero[i].length;i++) {
			
			
		
		
		
			
		
		}
		
	}
		
}

