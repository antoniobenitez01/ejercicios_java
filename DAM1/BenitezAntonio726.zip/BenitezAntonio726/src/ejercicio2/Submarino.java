/*
 * Clase que representa un Submarino
 * Extends: VehiculoAcuatico
 * Excepciones: IllegalArgumentException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 21/02/2025 
 */
package ejercicio2;

public class Submarino extends VehiculoAcuatico
{
	
// ATRIBUTOS ================================================================
	
	private double maxProfundidad;
	
// CONSTRUCTORES ============================================================
	
	//Constructor maestro (4 parámetros)
	public Submarino(String matricula, String modelo, double eslora, double maxProfundidad) throws IllegalArgumentException
	{
		super(matricula, modelo, eslora);
		
		if(maxProfundidad < 0)
		{
			throw new IllegalArgumentException("La profundida máxima no puede ser menor que 0.");
		}
		
		this.maxProfundidad = maxProfundidad;
	}
	
// GETTERS ===================================================================
	
	//Devuelve la profundidad máxima del Submarino como valor decimal double
	public double getMaxProfundidad()
	{
		return this.maxProfundidad;
	}
	
// SETTERS ===================================================================
	
	//Establece la profunidad máxima del Submarino
	public void setMaxProfundidad(double maxProfundidad)
	{
		if(maxProfundidad < 0)
		{
			throw new IllegalArgumentException("La profundida máxima no puede ser menor que 0.");
		}
		this.maxProfundidad = maxProfundidad;
	}
	
// MÉTODOS ====================================================================
	
	//TO STRING - Devuelve un String con la información del Submarino
	@Override
	public String toString()
	{
		return String.format("%s\nProfundidad máxima: %.2f m",super.toString(), this.maxProfundidad);
	}
}
