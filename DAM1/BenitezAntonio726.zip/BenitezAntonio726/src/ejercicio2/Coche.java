/*
 * Clase que representa un Coche
 * Extends: VehiculoTerrestre
 * Excepciones: IllegalArgumentException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 21/02/2025 
 */
package ejercicio2;

public class Coche extends VehiculoTerrestre
{
	
// ATRIBUTOS ===========================================================
	
	private boolean tieneAc;
	
// CONSTRUCTORES =======================================================
	
	//Constructor maestro (4 parámetros)
	public Coche(String matricula, String modelo, short numeroRuedas, boolean tieneAc)
	{
		super(matricula, modelo, numeroRuedas);
		
		this.tieneAc = tieneAc;
	}
	
// GETTERS =============================================================
	
	//Devuelve true si el Coche tiene aire acondicionado
	public boolean tieneAc()
	{
		return this.tieneAc;
	}
	
// SETTERS =============================================================
	
	//Establece el booleano de tieneAc
	public void setTieneAc(boolean tieneAc)
	{
		this.tieneAc = tieneAc;
	}

// MÉTODOS =============================================================
	
	//TO STRING - Devuelve un String con la información del Coche
	@Override
	public String toString()
	{
		return String.format("%s\nTiene Aire acondicionado: %s", super.toString(), this.tieneAc ? "Sí" : "No");
	}
}
