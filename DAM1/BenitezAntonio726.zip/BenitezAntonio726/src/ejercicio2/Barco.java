/*
 * Clase que representa un Barco
 * Extends: VehiculoAcuatico
 * Excepciones: IllegalArgumentException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 21/02/2025 
 */
package ejercicio2;

public class Barco extends VehiculoAcuatico
{

// ATRIBUTOS ===========================================================================
	
	private boolean tieneMotor;
	
// CONSTRUCTORES =======================================================================
	
	//Constructor maestro (4 parámetros)
	public Barco(String matricula, String modelo,double eslora, boolean tieneMotor)
	{
		super(matricula, modelo, eslora);
		
		this.tieneMotor = tieneMotor;
	}
	
// GETTERS ==============================================================================
	
	//Devuelve true si el Barco tiene motor
	public boolean tieneMotor()
	{
		return this.tieneMotor;
	}

// SETTERS ==============================================================================
	
	//Establece el booleano tieneBarco
	public void setTieneMotor(boolean tieneMotor)
	{
		this.tieneMotor = tieneMotor;
	}
	
// MÉTODOS ==============================================================================
	
	//TO STRING - Devuelve un String con la información del Barco
	@Override
	public String toString()
	{
		return String.format("%s\nTiene motor: %s",super.toString(), this.tieneMotor ? "Sí" : "No");
	}
}
