/*
 * Clase que representa un Vehiculo Aéreo
 * Extends: Vehiculo
 * Excepciones: IllegalArgumentException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 21/02/2025 
 */
package ejercicio2;

public class VehiculoAereo extends Vehiculo
{
	
// ATRIBUTOS ===============================================================
			
	private final short numAsientos;
			
// CONSTRUCTORES ===========================================================
		
	//Constructor maestro (3 parámetros)
	public VehiculoAereo(String matricula, String modelo, short numAsientos) throws IllegalArgumentException
	{
		super(matricula, modelo, "[A-Z]{4}[0-9]{6}");
				
		if(numAsientos < 1)
		{
			throw new IllegalArgumentException("El número de asientos no puede ser menor que 1.");
		}
				
		this.numAsientos = numAsientos;
	}
			
// GETTERS ==================================================================
			
	//Devuelve el número de ruedas del Vehículo Terrestre como entero short
	public short getNumeroAsientos()
	{
		return this.numAsientos;
	}
			
// MÉTODOS ==================================================================
			
	//TO STRING - Devuelve un String con la información del Vehículo Terrestre
	@Override
	public String toString()
	{
		return String.format("%s\nNúmero de asientos: %d", super.toString(), this.numAsientos);
	}
}
