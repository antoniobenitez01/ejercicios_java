/*
 * Clase Principal que hace uso de las clases creadas
 * Vehiculo, VehiculoTerrestre, VehiculoAcuatico, VehiculoAereo,
 * Coche, Moto, Barco, Submarino, Avion y Helicoptero
 * para utilizar sus constructores y métodos.
 * Excepciones: IllegalArgumentException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 21/02/2025
 */
package ejercicio2;

public class Principal {

	public static void main(String[] args) 
	{
		Coche coche; Moto moto; Barco barco; Submarino submarino; Avion avion; Helicoptero helicoptero;
		
		// CLASE COCHE =====================================================================================
		System.out.println("\n=== COCHE ===\n");
		
		try
		{
			System.out.println("Creando objeto Coche con parámetros inválidos de Vehículo ...");
			coche = new Coche("5555AA","Toyota", (short) 4, true);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", coche.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Coche con parámetros inválidos de Vehículo Terrestre ...");
			coche = new Coche("5555AAA","Toyota", (short) -5, true);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", coche.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Coche con parámetros correctos ...");
			coche = new Coche("5555AAA","Toyota", (short) 4, true);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", coche.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		// CLASE MOTO =====================================================================================
		System.out.println("\n=== MOTO ===\n");
		
		try
		{
			System.out.println("Creando objeto Moto con parámetros inválidos de Vehículo ...");
			moto = new Moto("5555AA","Suzuki", (short) 4, "Rojo");
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", moto.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Moto con parámetros inválidos de Vehículo Terrestre ...");
			moto = new Moto("5555AAA","Suzuki", (short) -4, "Rojo");
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", moto.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Moto con parámetros inválidos de Moto ...");
			moto = new Moto("5555AAA","Suzuki", (short) 4, "");
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", moto.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Moto con parámetros correctos ...");
			moto = new Moto("5555AAA","Suzuki", (short) 4, "Rojo");
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", moto.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		// CLASE BARCO =====================================================================================
		System.out.println("\n=== BARCO ===\n");
		
		try
		{
			System.out.println("Creando objeto Barco con parámetros inválidos de Vehículo ...");
			barco = new Barco("AAAAAAAAAAA","Divesea", 150.50, false);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", barco.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Barco con parámetros inválidos de Vehículo Acuático ...");
			barco = new Barco("AAAAAAAAAA","Divesea", -150.50, false);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", barco.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Barco con parámetros correctos ...");
			barco = new Barco("AAAAAAAAAA","Divesea", 150.50, false);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", barco.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		// CLASE SUBMARINO =====================================================================================
		System.out.println("\n=== SUBMARINO ===\n");
		
		try
		{
			System.out.println("Creando objeto Submarino con parámetros inválidos de Vehículo ...");
			submarino = new Submarino("AAAAAAAAAAA","DeepSea", 150.50, 1000);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", submarino.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Submarino con parámetros inválidos de Vehículo Acuático ...");
			submarino = new Submarino("AAAAAAAAAA","DeepSea", -150.50, 1000);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", submarino.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Submarino con parámetros inválidos de Submarino ...");
			submarino = new Submarino("AAAAAAAAAA","DeepSea", 150.50, -1000);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", submarino.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Submarino con parámetros correctos ...");
			submarino = new Submarino("AAAAAAAAAA","DeepSea", 150.50, 1000);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", submarino.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		// CLASE AVION =====================================================================================
		System.out.println("\n=== AVION ===\n");
		
		try
		{
			System.out.println("Creando objeto Avion con parámetros inválidos de Vehículo ...");
			avion = new Avion("AAAA9999999","SkyHigh", (short) 30, 1800);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", avion.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Avion con parámetros inválidos de Vehículo Aéreo ...");
			avion = new Avion("AAAA999999","SkyHigh", (short) -30, 1800);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", avion.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Avion con parámetros inválidos de Avión ...");
			avion = new Avion("AAAA999999","SkyHigh", (short) 30, -1800);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", avion.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Avion con parámetros correctos ...");
			avion = new Avion("AAAA999999","SkyHigh", (short) 30, 1800);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", avion.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		// CLASE HELICOPTERO =====================================================================================
		System.out.println("\n=== HELICOPTERO ===\n");
		
		try
		{
			System.out.println("Creando objeto Helicoptero con parámetros inválidos de Vehículo ...");
			helicoptero = new Helicoptero("AAAA9999999","HighVelo", (short) 30, (short) 5);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", helicoptero.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Helicoptero con parámetros inválidos de Vehículo Aéreo...");
			helicoptero = new Helicoptero("AAAA999999","HighVelo", (short) -30, (short) 5);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", helicoptero.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Helicoptero con parámetros inválidos de Helicoptero...");
			helicoptero = new Helicoptero("AAAA999999","HighVelo", (short) 30, (short) -5);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", helicoptero.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
		
		try
		{
			System.out.println("\nCreando objeto Helicoptero con parámetros correctos ...");
			helicoptero = new Helicoptero("AAAA999999","HighVelo", (short) 30, (short) 5);
			System.out.println("Creado con éxito.");
			System.out.printf("%s\n", helicoptero.toString());
		}catch(IllegalArgumentException ex)
		{
			System.out.printf("%s\n", ex.getMessage());
		}
	}
}
