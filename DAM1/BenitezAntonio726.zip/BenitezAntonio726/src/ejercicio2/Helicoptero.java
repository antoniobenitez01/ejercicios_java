/*
 * Clase que representa un Helicoptero
 * Extends: VehiculoAereo
 * Excepciones: IllegalArgumentException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 21/02/2025 
 */
package ejercicio2;

public class Helicoptero extends VehiculoAereo
{
	
// ATRIBUTOS ======================================================
	
	private short numHelices;

// CONSTRUCTORES ==================================================
	
	public Helicoptero(String matricula, String modelo, short numAsientos, short numHelices) throws IllegalArgumentException
	{
		super(matricula, modelo, numAsientos);
		
		if(numHelices < 1)
		{
			throw new IllegalArgumentException("El número de hélices no puede ser menor que 1");
		}
		
		this.numHelices = numHelices;
	}
	
// GETTERS ========================================================
	
	//Devuelve el número de hélices del Helicoptero como valor entero short
	public short getNumHelices()
	{
		return this.numHelices;
	}
	
// SETTERS =========================================================
	
	//Establece el número de hélices del Helicoptero
	public void setNumHelices(short numHelices)
	{
		if(numHelices < 1)
		{
			throw new IllegalArgumentException("El número de hélices no puede ser menor que 1");
		}
		this.numHelices = numHelices;
	}
	
// MÉTODOS =========================================================
	
	//TO STRING - Devuelve un String con la información del Helicoptero
	public String toString()
	{
		return String.format("%s\nNúmero de hélices: %d", super.toString(), this.numHelices);
	}
}
