/*
 * Clase abstracta que representa un Vehiculo
 * Excepciones: IllegalArgumentException
 * Autor: Antonio Benítez Rodríguez
 * Fecha: 21/02/2025 
 */
package ejercicio2;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class Vehiculo 
{
	
// ATRIBUTOS =====================================================================
	
	protected final String matricula;
	protected final String modelo;
	protected final String patronString;
	
// CONSTRUCTORES =================================================================
	
	//Constructor maestro (3 parámetros)
	public Vehiculo(String matricula, String modelo, String patronString) throws IllegalArgumentException
	{
		if(patronString.isEmpty() || patronString == null)
		{
			throw new IllegalArgumentException("El patrón no puede ser nulo o vacío.");
		}
		this.patronString = patronString;
		Pattern patron = Pattern.compile(patronString);
		Matcher match = patron.matcher(matricula);
		if(!match.matches())
		{
			throw new IllegalArgumentException(String.format("El patrón de la matrícula es incorrecto."
					+ "\nDebe seguir la siguiente expresión regular: %s", this.patronString));
		}
		
		if(matricula.isEmpty() || matricula == null)
		{
			throw new IllegalArgumentException("La matrícula no puede ser nula o vacía.");
		}
		if(modelo.isEmpty() || modelo == null)
		{
			throw new IllegalArgumentException("El modelo no puede ser nulo o vacío.");
		}
		
		this.matricula = matricula;
		this.modelo = modelo;
	}
	
// GETTERS ========================================================================
	
	//Devuelve la matrícula del Vehiculo en formato String
	public String getMatricula()
	{
		return this.matricula;
	}
	
	//Devuelve el modelo del Vehículo en formato String
	public String getModelo()
	{
		return this.modelo;
	}
	
// MÉTODOS ========================================================================
	
	//TO STRING - Devuelve un String con la información del Vehiculo
	public String toString()
	{
		return String.format("Matrícula: %s\nModelo: %s", this.matricula, this.modelo);
	}
}
