package ejercicioA3;

public class Rectangulo 
{
	int x1;
	int y1;
	int x2;
	int y2;
}
