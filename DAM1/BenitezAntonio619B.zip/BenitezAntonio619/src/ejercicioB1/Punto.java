package ejercicioB1;

public class Punto 
{
	int x;
	int y;
	
	//CONSTRUCTORES
	public Punto(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}
