package ejercicioA4;

public class Articulo 
{
	static final double IVA = 21;
	String nombre;
	double precio;
	int cuantosQuedan;
}
