package ejercicioA1;

public class Punto 
{
	int x;
	int y;
}
