package ejercicioA2;

public class Persona 
{
	String dni;
	String nombre;
	String apellidos;
	int edad;
}
